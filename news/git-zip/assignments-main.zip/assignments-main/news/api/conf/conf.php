<?php

const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASSWD = '';
const DB_DATABASE = 'clique_news';

?>