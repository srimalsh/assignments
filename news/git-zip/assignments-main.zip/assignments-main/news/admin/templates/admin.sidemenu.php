<aside class="wrapper-menu">
    <ul>
        <li>asdsad</li>
        <li>asdsad</li>
        <li>asdsad</li>
        <li>asdsad</li>
    </ul>
</aside>