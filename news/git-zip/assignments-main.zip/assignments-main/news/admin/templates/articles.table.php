<div class="table-wrapper-generic">
    <table>
        <tr>
            <th>Company</th>
            <th>Contact</th>
            <th>Country</th>
            <th>Action</th>
        </tr>
        <tr>
            <td>Alfreds Futterkiste</td>
            <td>Maria Anders</td>
            <td>Germany</td>
            <td>Delete</td>
        </tr>
        <tr>
            <td><a href="#" class="cool">Centro comercial Moctezuma</a></td>
            <td>Francisco Chang</td>
            <td>Mexico</td>
            <td>Delete</td>
        </tr>
        <tr>
            <td>Ernst Handel</td>
            <td>Roland Mendel</td>
            <td>Austria</td>
            <td><a href="#" class="warn">Delete</a></td>
        </tr>
        <tr>
            <td>Island Trading</td>
            <td>Helen Bennett</td>
            <td>UK</td>
            <td>Delete</td>
        </tr>
        <tr>
            <td>Laughing Bacchus Winecellars</td>
            <td>Yoshi Tannamuri</td>
            <td>Canada</td>
            <td>Delete</td>
        </tr>
        <tr>
            <td>Magazzini Alimentari Riuniti</td>
            <td>Giovanni Rovelli</td>
            <td>Italy</td>
            <td>Delete</td>
        </tr>
    </table>
</div>